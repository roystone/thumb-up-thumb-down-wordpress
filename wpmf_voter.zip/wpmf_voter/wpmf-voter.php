<?php
/*
Plugin Name: WPMF Voter
Plugin URI: 
Description: WordPress Music Forest Voter PHP Script
Version: 1.0
Author: KodeForest
Author URI: http://www.kodeforest.com
License: 
*/

register_activation_hook(__FILE__,'wpha_create_voting_table');
function wpha_create_voting_table(){
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	global $wpdb;
	
	// for payment transaction
	$table_name = 'wp_votusers';
	$sql = "CREATE TABLE $table_name (
		`day` INT(2), 
		`voter` VARCHAR(15), 
		`item` VARCHAR(200) NOT NULL DEFAULT ''
	) DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;";
	dbDelta( $sql );	

	$table_name = 'wp_voting';
	$sql = "CREATE TABLE $table_name (
		`item` VARCHAR(200) PRIMARY KEY NOT NULL DEFAULT '',
		`vote` INT(10) NOT NULL DEFAULT 0,
		`nvotes` INT(9) NOT NULL DEFAULT 1
	) DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;";
	dbDelta( $sql );	
	
}

if(!is_admin()){
	add_action('wp_enqueue_scripts','bethany_get_video_scripts');
}

if( !function_exists('bethany_get_video_scripts') ){
	function bethany_get_video_scripts(){
		
		wp_register_script('wpmf-voting', plugin_dir_url( __FILE__ ).'/voter-includes/voting.js', false, '1.0', true);
		wp_localize_script('wpmf-voting', 'ajax_var', array('PLUGIN_PATH' => plugin_dir_url( __FILE__ )));
		wp_enqueue_script('wpmf-voting');
		wp_enqueue_style( 'wpmf-voting', plugin_dir_url( __FILE__ ) . '/voter-includes/voting.css' );  //prettyphoto
		
	}
}